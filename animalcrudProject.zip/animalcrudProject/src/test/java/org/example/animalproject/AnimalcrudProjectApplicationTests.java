package org.example.animalproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalcrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
