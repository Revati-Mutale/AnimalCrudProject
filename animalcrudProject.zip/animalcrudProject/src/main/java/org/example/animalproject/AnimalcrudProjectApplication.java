package org.example.animalproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalcrudProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalcrudProjectApplication.class, args);
	}

}
